package att.grappa;

public interface IGrappaObjectListener {
	public void update(Object obs, Object arg) ;
}
